package com.br.fiap.skill_match.dto;

import java.util.List;

public record UserResponseDTO(
        Long id,
        String nome,
        String email,
        List<String> roles
) {}
