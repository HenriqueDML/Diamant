package com.br.fiap.skill_match;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkillMatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkillMatchApplication.class, args);
	}

}
