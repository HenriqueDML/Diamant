
package com.br.fiap.skill_match.dto;

public class FeedbackStatsDTO {
    private String mes;
    private long positivos;
    private long negativos;

    public FeedbackStatsDTO(String mes, long positivos, long negativos) {
        this.mes = mes;
        this.positivos = positivos;
        this.negativos = negativos;
    }

    public String getMes() {
        return mes;
    }

    public void setMes(String mes) {
        this.mes = mes;
    }

    public long getPositivos() {
        return positivos;
    }

    public void setPositivos(long positivos) {
        this.positivos = positivos;
    }

    public long getNegativos() {
        return negativos;
    }

    public void setNegativos(long negativos) {
        this.negativos = negativos;
    }
}
