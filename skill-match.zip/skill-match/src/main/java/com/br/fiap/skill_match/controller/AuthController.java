package com.br.fiap.skill_match.controller;

import com.br.fiap.skill_match.dto.LoginRequestDTO;
import com.br.fiap.skill_match.dto.LoginResponseDTO;
import com.br.fiap.skill_match.model.User;
import com.br.fiap.skill_match.repository.UserRepository;
import com.br.fiap.skill_match.security.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    JwtUtils jwtUtils;

    @Autowired
    UserRepository userRepository;

    @Autowired
    PasswordEncoder passwordEncoder;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequestDTO credentials) {
        Optional<User> userOpt = userRepository.findByEmail(credentials.getEmail());

        if (userOpt.isEmpty()) {
            return ResponseEntity.status(401).body("Usuário não encontrado");
        }

        User user = userOpt.get();

        if (!passwordEncoder.matches(credentials.getPassword(), user.getSenha())) {
            return ResponseEntity.status(401).body("Senha inválida");
        }

        String token = jwtUtils.generateToken(user.getEmail());
        return ResponseEntity.ok(new LoginResponseDTO(token));
    }
}
