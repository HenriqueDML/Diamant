package com.br.fiap.skill_match.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.br.fiap.skill_match.model.Feedback;
import com.br.fiap.skill_match.model.User;
import com.br.fiap.skill_match.repository.FeedbackRepository;
import com.br.fiap.skill_match.repository.UserRepository;
import com.br.fiap.skill_match.model.Role;
import com.br.fiap.skill_match.repository.RoleRepository;
import org.springframework.security.crypto.password.PasswordEncoder;

import jakarta.annotation.PostConstruct;

@Component
public class DatabaseSeeder {

    @Autowired
    private FeedbackRepository feedbackRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;


    @PostConstruct
    public void init() {
        // Feedbacks
        feedbackRepository.saveAll(List.of(
                Feedback.builder()
                        .userName("João Silva")
                        .comment("Excelente trabalho em equipe!")
                        .rating(5)
                        .build(),
                Feedback.builder()
                        .userName("Maria Oliveira")
                        .comment("Muito proativo e colaborativo")
                        .rating(4)
                        .build(),
                Feedback.builder()
                        .userName("Pedro Souza")
                        .comment("Ótima comunicação")
                        .rating(5)
                        .build()
        ));

        if (userRepository.findByEmail("admin@email.com").isEmpty()) {
            Role adminRole = roleRepository.findByNome("ROLE_ADMIN")
                    .orElseGet(() -> roleRepository.save(Role.builder().nome("ROLE_ADMIN").build()));
            Role userRole = roleRepository.findByNome("ROLE_USER")
                    .orElseGet(() -> roleRepository.save(Role.builder().nome("ROLE_USER").build()));

            User user = new User();
            user.setNome("Admin");
            user.setEmail("admin@email.com");
            user.setSenha(passwordEncoder.encode("123456"));
            user.setRoles(List.of(adminRole, userRole));
            userRepository.save(user);

        }
    }
}
