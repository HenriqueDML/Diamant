package com.br.fiap.skill_match.controller;

import com.br.fiap.skill_match.dto.UserRequestDTO;
import com.br.fiap.skill_match.dto.UserResponseDTO;
import com.br.fiap.skill_match.model.Role;
import com.br.fiap.skill_match.model.User;
import com.br.fiap.skill_match.repository.RoleRepository;
import com.br.fiap.skill_match.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/cadastro")
@CrossOrigin(origins = "*")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping
    public ResponseEntity<UserResponseDTO> cadastrar(@RequestBody @Valid UserRequestDTO dto) {
        if (userRepository.findByEmail(dto.email()).isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }

        Role roleUser = roleRepository.findByNome("ROLE_USER")
                .orElseThrow(() -> new RuntimeException("ROLE_USER não encontrada"));

        User user = new User();
        user.setNome(dto.nome());
        user.setEmail(dto.email());
        user.setSenha(passwordEncoder.encode(dto.senha()));
        user.setRoles(List.of(roleUser));

        User salvo = userRepository.save(user);

        UserResponseDTO response = new UserResponseDTO(
                salvo.getId(),
                salvo.getNome(),
                salvo.getEmail(),
                salvo.getRoles().stream().map(Role::getNome).toList()
        );

        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping
    public List<UserResponseDTO> listar() {
        return userRepository.findAll().stream().map(user ->
                new UserResponseDTO(
                        user.getId(),
                        user.getNome(),
                        user.getEmail(),
                        user.getRoles().stream().map(Role::getNome).toList()
                )
        ).toList();
    }
}
