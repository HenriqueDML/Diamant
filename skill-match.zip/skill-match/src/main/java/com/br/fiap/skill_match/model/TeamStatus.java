package com.br.fiap.skill_match.model;

public enum TeamStatus {
    ACTIVE, // Grupo ATIVO
    INACTIVE, // Grupo INATIVO
    COMPLETED // Grupo FINALIZADO

}
