package com.br.fiap.skill_match;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkillMatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
